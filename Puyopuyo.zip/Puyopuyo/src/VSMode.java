import player.Maou;
import jp.ac.nagoya_u.is.ss.kishii.usui.system.game.AbstractPlayer;
import jp.ac.nagoya_u.is.ss.kishii.usui.system.game.PuyoPuyo;
import moc.liamtoh900ognek.KajiGOD3;
import moc.liamtoh900ognek.KajiGodGod;
import UsuiPlayer.UsuiPlayer;



/**
 * 任意の二体のエージェント同士を対戦させるためのクラス
 */
public class VSMode {

	public static void main(String args[]) {
		/**
		 * 任意の二つのエージェントを読み込む．<br>
		 */
		AbstractPlayer player1 = new Maou("N天堂");
		AbstractPlayer player2 = new KajiGOD3("TA1");
		AbstractPlayer playerKajiGodGod = new KajiGodGod("梶原");
		AbstractPlayer player3 = new UsuiPlayer("TA2");
		
		PuyoPuyo puyopuyo = new PuyoPuyo(playerKajiGodGod, player1);
		puyopuyo.puyoPuyo();



	}
}
