package jp.ac.nagoya_u.is.ss.kishii.usui.system.viewer;

import javax.swing.JPanel;

public class SpaceMaker extends JPanel{
	public SpaceMaker() {
		setOpaque(false);
	}
}
