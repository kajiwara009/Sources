package jp.ac.nagoya_u.is.ss.kishii.usui.system.storage;

/**
 * ぷよの色を表す列挙型クラスです。
 *
 */
public enum PuyoType {
	BLUE_PUYO,
	RED_PUYO,
	GREEN_PUYO,
	YELLOW_PUYO,
	PURPLE_PUYO,
	OJAMA_PUYO ;
}
