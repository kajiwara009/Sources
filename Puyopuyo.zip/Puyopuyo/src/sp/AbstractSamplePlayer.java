package sp;

import jp.ac.nagoya_u.is.ss.kishii.usui.system.game.AbstractPlayer;


abstract public class AbstractSamplePlayer extends AbstractPlayer {

	
	
	public AbstractSamplePlayer() {
		super("Sample");
	}

	

	@Override
	public void initialize() {
		// TODO 自動生成されたメソッド・スタブ

	}

	@Override
	public void inputResult() {
		// TODO 自動生成されたメソッド・スタブ

	}

}
