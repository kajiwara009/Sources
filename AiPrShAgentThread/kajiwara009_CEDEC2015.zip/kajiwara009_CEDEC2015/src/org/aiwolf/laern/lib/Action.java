package org.aiwolf.laern.lib;

public enum Action {
	VOTE, DIVINE, GUARD;

}
