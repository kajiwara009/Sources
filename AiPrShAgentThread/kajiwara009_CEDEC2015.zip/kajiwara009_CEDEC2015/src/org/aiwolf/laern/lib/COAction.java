package org.aiwolf.laern.lib;


public enum COAction {
	DO, DONT;
}
