package org.aiwolf.kajiPlayer.profitSharing;

import org.aiwolf.common.data.Role;

public class PrShVillager extends PrShBasePlayer{

	public PrShVillager() {
		super(Role.VILLAGER);
	}
	

}
