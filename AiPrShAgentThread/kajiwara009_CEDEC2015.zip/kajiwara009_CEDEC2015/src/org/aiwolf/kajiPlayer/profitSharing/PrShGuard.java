package org.aiwolf.kajiPlayer.profitSharing;

import org.aiwolf.common.data.Role;

public class PrShGuard extends PrShBasePlayer{

	public PrShGuard() {
		super(Role.BODYGUARD);
	}
	

}
